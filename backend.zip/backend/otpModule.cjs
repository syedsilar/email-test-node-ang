const nodemailer = require('nodemailer');
class Email_OTP_Module {
  constructor() {
    return 'Welcome to Syed silar portal!'
  }

  generate_OTP_email () {
    return Math.floor(100000 + Math.random() * 900000);
  }

  async send_email(email_address) {
    const STATUS_EMAIL_OK = 'STATUS_EMAIL_OK';
    const STATUS_EMAIL_FAIL = 'STATUS_EMAIL_FAIL';
    const STATUS_EMAIL_INVALID = 'STATUS_EMAIL_INVALID';
    const otp = this.generate_OTP_email();
    const email_body = `Your OTP Code is ${otp}. The code is valid for 1 minute.`;
    const validDomain = email_address.endsWith('dso.org.sg');
    if (!validDomain) {
      return { status: STATUS_EMAIL_INVALID, status_message : "email address is invalid." };
    }

    
    
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'GIVE_UR_SENDER_EMAIL', 
        pass: 'GIVE_UR_SENDER_EMAIL_PASSWORD',  
      },
    });

    try {
      const info = await transporter.sendMail({
        from: 'GIVE_UR_SENDER_EMAIL', 
        to:  email_address,
        subject: 'Your OTP Code',
        text: email_body,
      });

      return { status: STATUS_EMAIL_OK, otpGenerated : otp, status_message : "email containing OTP has been sent successfully."  };
    } catch (error) {
      console.error('Error sending email:', error);
      return { status: STATUS_EMAIL_FAIL, status_message : "email address does not exist or sending to the email has failed."};
    }
  

  }

}

module.exports = Email_OTP_Module;
