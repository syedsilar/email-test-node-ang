import express from 'express';
import EmailOTPModule from './otpModule.cjs';
import cors from 'cors';

const app = express();
const port = 3000;
app.use(express.json());  
app.use(cors());
 
const otpModule = new EmailOTPModule();
const MAX_TRIES = 10;
let totalTries  = 0;

app.post('/generate-otp', async (req, res) => {
    const email_address = req.body.email;
    
    if (!email_address) {
      return res.json({ error: 'Email is required in the query parameters' });
    }
    try {
      const result = await otpModule.send_email(email_address );
      res.json(result);
    } catch (error) {
      console.error('Error generating and sending OTP:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

app.post('/check-otp', async (req, res) => {
  const { input, expectedOTP } = req.body;
  if (!input) {
    return res.json({ status: 'INVALID_OTP' });
  }

  const enteredOTP = parseInt(input);

  if (totalTries < MAX_TRIES) {
    if (enteredOTP === expectedOTP) {
      totalTries = 0;
      return res.json({ status: 'STATUS_OTP_OK', status_message:'OTP is valid and checked' });
    } else {
      totalTries++;
      return res.json({ status_message: 'Try Again!' });
    }
  } else {
    totalTries = 0;
    return res.json({ status: 'STATUS_OTP_FAIL', status_message:'OTP is wrong after 10 tries'});
  }

});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);

});
