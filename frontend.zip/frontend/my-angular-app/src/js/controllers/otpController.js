angular.module('otpApp')
  .controller('OTPCtrl', function ($scope, $http, $timeout) {
    $scope.otpGenerated = false;
    $scope.otpChecked = false;
    $scope.enteredOTP = '';
    $scope.resultMessage = '';
    $scope.email = '';
    $scope.generateOtpResult = null;

    $scope.generateOTP = function () {

      if (!isValidEmail($scope.email)) {
        $scope.invalidEmail = true;
        return;
      }

      $scope.invalidEmail = false;
      $scope.errorMessage = '';
      $http.post(`http://127.0.0.1:3000/generate-otp`, { email: $scope.email })
        .then(response => {
          const generateOtpResult = response.data;
          if (generateOtpResult.status === 'STATUS_EMAIL_OK') {
            $scope.invalidEmail = true;
            $scope.errorMessage = generateOtpResult.status_message
            $scope.otpGenerated = true;
            $scope.generateOtpResult = generateOtpResult;
            $timeout(() => {
              $scope.generateOtpResult = null;
              $scope.invalidEmail = true;
              $scope.errorMessage = 'timeout after 1 min';
              $scope.otpChecked = false;
              $scope.otpGenerated = false;
            }, 60000);
          } else {
            $scope.invalidEmail = true;
            $scope.errorMessage = generateOtpResult.status_message;
            console.error('Error generating OTP:', generateOtpResult.error);
          }
        })
        .catch(error => console.error('Error generating OTP:', generateOtpResult.error));
    };

    $scope.checkOTP = function () {
      if (!$scope.generateOtpResult) {
        $scope.resultMessage = 'OTP generation timeout';
        return;
      }

      const data = {
        input: $scope.enteredOTP,
        expectedOTP: $scope.generateOtpResult.otpGenerated,
      };

      $http.post('http://127.0.0.1:3000/check-otp', data)
        .then(response => {
          const checkOTPResult = response.data;
          if (checkOTPResult.status === 'STATUS_OTP_FAIL') {
            $scope.otpGenerated = false;
          }
          $scope.otpChecked = true;
          $scope.resultMessage = response.data.status_message;
        })
        .catch(error => console.error('Error checking OTP:', error));
    };

     function isValidEmail(email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    }

  });
