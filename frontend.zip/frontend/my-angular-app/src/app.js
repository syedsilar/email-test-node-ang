// js/app.js
angular.module('otpApp', []);
